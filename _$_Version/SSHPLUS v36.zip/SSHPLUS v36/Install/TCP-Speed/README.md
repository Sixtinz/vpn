﻿# TCP-Tweaker-1.0 (TCP-SPEED)

![logo](https://github.com/AAAAAEXQOSyIpN2JZ0ehUQ/SSHPLUS-MANAGER-FREE/blob/master/Imagenes/TCP_Tweaker_TCP_SPEED.jpg)

## :book: Installation

apt-get update -y; apt-get upgrade -y; wget https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/SSHPLUS-MANAGER-FREE/master/Install/tcptweaker.sh; chmod +x tcptweaker.sh; ./tcptweaker.sh

```
PARA EJECUTAR NUEVAMENTE TCP-SPPED EXECUTE EL COMANDO ( ./tcptweaker.sh )
```
-------------------------------------------------------------------------------

## :octocat: Contribute

1. @Phreaker56 - Developer of TCP-Tweaker-1.0 (TCP-SPEED) (Website: https://phreaker56.obex.pw/)
2. Team Illuminati - Contributor 

```
* SIN MINERIA! 
* SIN KEYS! 
* VERSION GRATUITA 
* SIN VIRUS TROJANO (BOTNET) 
* ARCHIVOS LIBERADOS (DECENCRIPTADOS)
```

```
☆ https://t.me/admmanagerfree ☆
```

**By: [  ⃘⃤꙰✰ ]**